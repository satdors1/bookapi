const config = {
    awsconfig:{
            region:  "region",
            endpoint: "endpoint",
            accessKeyId: "accesskey",
            secretAccessKey: "secret access key"
    }

}
module.exports = config;